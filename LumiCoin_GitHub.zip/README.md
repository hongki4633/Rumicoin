
# LumiCoin (LUMI) 🌕

**LumiCoin**은 비트코인의 철학을 이어받아,  
빛처럼 투명하고 공정한 디지털 화폐를 목표로 합니다.  
총 발행량 10조 개, 누구나 채굴할 수 있는 기능을 갖춘  
ERC-20 기반의 미래형 토큰입니다.

---

## ✨ 토큰 정보

| 항목         | 내용 |
|--------------|------|
| **이름**      | LumiCoin |
| **심볼**      | LUMI |
| **소수점**    | 8자리 (비트코인과 동일) |
| **총 발행량** | 10,000,000,000,000 LUMI (10조 개) |
| **네트워크**  | Ethereum (또는 Sepolia Testnet) |
| **컨트랙트 주소** | `0x...` ← 배포 후 입력 |

---

## ⚙️ 주요 기능

### ✅ 기본 기능
- ERC-20 기반: transfer, approve, transferFrom 지원
- mine(): 한 지갑당 1회 채굴 가능 (10 LUMI)
- setMiningReward(): 배포자만 보상량 변경 가능

---

## ⛏ 채굴 방법 (mine)

1. Remix 또는 Web3 인터페이스에서 `mine()` 함수 실행
2. 메타마스크 지갑으로 서명
3. 자동으로 10 LUMI가 발행됨 (1회 한정)

---

## 🌐 관련 링크

- [스마트컨트랙트 보기](./contracts/LumiCoin.sol)
- [로고 이미지](./assets/LumiCoin-logo.png)
- [백서 (한글)](./whitepaper.md)
- [Etherscan에서 보기](https://sepolia.etherscan.io/address/0x...) ← 주소 넣기

---

## 🧠 왜 LumiCoin인가?

> “돈이란 신뢰에서 시작되고,  
> LumiCoin은 신뢰를 빛처럼 발행합니다.”

---

## 📄 라이선스

MIT License  
© 2025 Honggi
